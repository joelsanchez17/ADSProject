package core_tile

import chisel3._
import chisel3.experimental.ChiselEnum
import chisel3.util._
import chisel3.util.experimental.loadMemoryFromFile

import ALUOpT._
import aluOpAMux._
import aluOpBMux._

class ALU extends Module {
    val io = IO(new Bundle {
        val ALUOp = Input(ALUOpT())
        val operandA = Input(UInt(32.W))
        val operandB = Input(UInt(32.W))
        val aluResult = Output(UInt(32.W))
    })

    when(io.ALUOp === isADD)       {io.aluResult := io.operandA + io.operandB}
    .elsewhen(io.ALUOp === isSUB)  {io.aluResult := io.operandA - io.operandB}
    .elsewhen(io.ALUOp === isOR)   {io.aluResult := io.operandA | io.operandB}
    .elsewhen(io.ALUOp === isSLL)  {io.aluResult := io.operandA << io.operandB(4, 0)}
    .elsewhen(io.ALUOp === isSRA)  {io.aluResult := (io.operandA.asSInt >> io.operandB(4, 0)).asUInt}          // automatic sign extension, if SInt datatype is use
    .elsewhen(io.ALUOp === isPASSB){io.aluResult := io.operandB} // pass immediate value (OperandB) to result
    .otherwise                     {io.aluResult := "h_FFFF_FFFF".U} // = 2^32 - 1; self-defined encoding for invalid operation, value is unlikely to be reached in a regular arithmetic operation

}

